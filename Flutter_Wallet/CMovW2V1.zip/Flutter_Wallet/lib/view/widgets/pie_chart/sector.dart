

import 'dart:ui';

class Sector{

  final String title;
  final double value;
  final Color color;

  Sector(this.title, this.value, this.color);
}