
import 'dart:ui';

class IndividualBar{
  final int x;
  final double y;
  final Color color;

  IndividualBar(this.x, this.y, this.color);
}